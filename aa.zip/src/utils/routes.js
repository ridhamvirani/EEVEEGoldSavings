export const Routes = [
    {
        name: "Home",
        path: "/"
    },
    {
        name: "Plans",
        path: "/plans"
    },
    {
        name: "About",
        path: "/about"
    },
    {
        name: "Contact",
        path: "/contact"
    },
]